﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 4.5.2020
* CSC 153
* Sene Apulu
* TextAdventure3
* StandardMessages class.
* for message prompts.
*/

namespace TxtAdventureLib
{
    public class StdMsgs
    {
        //menu prompts
        public static string MenuHeader()
        {
            return "".PadRight(10) + "Menu" +
                   "".PadRight(10) + "\n-------------------------";

        }
        public static string MenuDisplay()
        {
            return "".PadRight(5) + "\n1. move north" +
                   "".PadRight(5) + "\n2. move south" +
                   "".PadRight(5) + "\n3. exit" +
                   "".PadRight(5) + "\n>>";
        }


        //create-a-player prompts
        public static string CreatePlayerHeader()
        {
            return "".PadLeft(20) +
                 "Create a player" +
                 "\n--------------------------------------------------------";
        }

        //GetName() prompts
        public static string EnterNamePrompt()
        {
            return "enter your name: ";
        }
        public static string YourNameIsPrompt(Player aPlayer)
        {
            return $"your name is { aPlayer.Name.ToUpper() }?";
        }

        public static string YesNoPrompt()
        {
            return "(Y/N): ";
        }
        public static string ConfirmedNamePrompt(Player aPlayer)
        {
            return $"Ok, {aPlayer.Name}. [enter]";
        }


        //GetClass() prompts
        public static string NamePlayerPrompt(Player aPlayer)
        {
            return $"name: {aPlayer.Name}\n";
        }
        public static string ClassOptionsPrompt()
        {
            return "1. Heavy" +
                 "\n2. Balanced" +
                 "\n3. Light" +
                 "\nChoose class: ";
        }
        public static string HeavyClassChoicePrompt()
        {
            return "Heavy class chosen. [enter]";
        }

        public static string BalancedClassChoicePrompt()
        {
            return "Balanced class chosen. [enter]";
        }

        public static string LightClassChoicePrompt()
        {
            return "Light class chosen. [enter]";
        }


        public static string ChooseClassPrompt() 
        {
            return "Choose class: ";
        }


        //GetRace() prompts
        public static string NameClassPlayerPrompt(Player aPlayer)
        {
            return $"name: {aPlayer.Name}" +
                   $"\nclass: {aPlayer.Class}";
        }
        public static string RaceOptionsPrompt()
        {
            return "1. Human" +
                 "\n2. Martian" +
                 "\n3. Galilean" +
                 "\nChoose race: ";
        }
        public static string HumanRaceChoicePrompt() 
        {
            return "Human race chosen. [enter]";
        }
        public static string MartianRaceChosenPrompt() 
        {
            return "Martian race chosen. [enter]";
        }
        public static string GalileanRaceChosenPrompt() 
        {
            return "Galilean race chosen. [enter]";
        }
        public static string ChooseRacePrompts() 
        {
            return "Choose race: ";
        }

        //GetPass() Prompts
        public static string NameClassRacePlayerPrompt(Player aPlayer)
        {
            return $"name: {aPlayer.Name}" +
                   $"\nclass: {aPlayer.Class}" +
                   $"\nrace: {aPlayer.Race}";
        }

        public static string EnterPwPrompt() 
        {
            return "enter a password: ";
        }
        public static string ConfirmPwPrompt() 
        {
            return "confirm your password: ";
        }
        public static string PwConfirmedPrompt() 
        {
            return "password confirmed. [enter]";
        }
        public static string PwMisMatchPrompt() 
        {
            return "your passwords didn't match. [enter]";
        }

        //Player prompts
        public static string DisplayLocation(Room[] roomArr, List<Player> playerList) //Display RoomName the Player occupies.
        {
            return $"Location: {roomArr[playerList[0].RoomLoc].RoomName}";
        }
        //movement
        public static string MovingNorthPrompt() 
        {
            return "moving north...[enter]";
        }

        public static string NoMoveNorthPrompt() 
        {
            return "can't move north. [enter]";
        }

        public static string MovingSouthPrompt()
        {
            return "moving south...[enter]";
        }

        public static string NoMoveSouthPrompt()
        {
            return "can't move south. [enter]";
        }

        //Misc Prompts
        public static string TryAgainPrompt() 
        {
            return "Ok, try again. [enter]";
        }

        public static string InvalidInputPrompt()
        {
            return "invalid input [enter]";
        }

        public static string ExitPrompt() 
        {
            return "exiting...";
        }
    }
}
