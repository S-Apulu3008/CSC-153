﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TxtAdventureLib
{
    public class BuildPlayer
    {
        public static void BuildAPlayer(List<Player> playerList)
        {
            Player newPlayer = new Player();

            GetName(newPlayer);
            GetClass(newPlayer);
            GetRace(newPlayer);
            GetPass(newPlayer);
            Console.Clear();
            Console.WriteLine(StdMsgs.CreatePlayerHeader());
            newPlayer.ShowPlayer();
            playerList.Add(newPlayer);

        }//end BuildAPlayer

        public static void GetName(Player newPlayer) //get a name for Player
        {
            bool error = true;
            do
            {
                Console.Clear();        //Clear Screen/Display Menu
                Console.WriteLine(StdMsgs.CreatePlayerHeader()); 

                                        //Get name and display
                Console.Write(StdMsgs.EnterNamePrompt());
                newPlayer.Name = Console.ReadLine();
                Console.WriteLine(StdMsgs.YourNameIsPrompt(newPlayer));

                                        //Confirm Name
                Console.Write(StdMsgs.YesNoPrompt());
                switch (Console.ReadLine().ToUpper())
                {
                    case "Y":
                        error = false;
                        Console.WriteLine(StdMsgs.ConfirmedNamePrompt(newPlayer));
                        Console.ReadLine();
                        break;
                    case "N":
                        Console.WriteLine(StdMsgs.TryAgainPrompt());
                        Console.ReadLine();
                        break;
                    default:
                        Console.WriteLine(StdMsgs.InvalidInputPrompt());
                        Console.ReadLine();
                        break;
                }
            } while (error == true);
        }

        public static void GetClass(Player newPlayer) //get a class for Player
        {
            bool error = true;
            Console.Clear();
            Console.WriteLine(StdMsgs.CreatePlayerHeader());
            Console.WriteLine(StdMsgs.NamePlayerPrompt(newPlayer));
            Console.WriteLine(StdMsgs.ClassOptionsPrompt());

            //TODO continue StdMsgs refactor. formatting needs improving.
            do
            {
                switch (Console.ReadLine())
                {
                    case "1":
                        Console.Write(StdMsgs.HeavyClassChoicePrompt());
                        newPlayer.Class = "Heavy";
                        error = false;
                        break;
                    case "2":
                        Console.WriteLine(StdMsgs.BalancedClassChoicePrompt());
                        newPlayer.Class = "Medium";
                        error = false;
                        break;
                    case "3":
                        Console.WriteLine(StdMsgs.LightClassChoicePrompt());
                        newPlayer.Class = "Light";
                        error = false;
                        break;
                    default:
                        Console.WriteLine(StdMsgs.ChooseClassPrompt());
                        break;
                }
            } while (error == true);
            Console.ReadLine();
        }

        public static void GetRace(Player newPlayer) 
        {
            bool error = true;
            Console.Clear();
            Console.WriteLine(StdMsgs.CreatePlayerHeader());
            Console.WriteLine(StdMsgs.NameClassPlayerPrompt(newPlayer));//Show name, class info.
            Console.WriteLine(StdMsgs.RaceOptionsPrompt());
            do
            {
                switch (Console.ReadLine())
                {
                    case "1":
                        Console.WriteLine(StdMsgs.HumanRaceChoicePrompt());
                        newPlayer.Race = "Human";
                        error = false;
                        break;

                    case "2":
                        Console.WriteLine(StdMsgs.MartianRaceChosenPrompt());
                        newPlayer.Race = "Martian";
                        error = false;
                        break;

                    case "3":
                        Console.WriteLine(StdMsgs.GalileanRaceChosenPrompt());
                        newPlayer.Race = "Galilean";
                        error = false;
                        break;

                    default:
                        Console.WriteLine(StdMsgs.ChooseRacePrompts());
                        break;
                }
            } while (error == true);
            Console.ReadLine();
        }

        public static void GetPass(Player newPlayer) 
        {
            string input, pwChk;
            bool error = true;


            do
            {
                Console.Clear();
                Console.WriteLine(StdMsgs.CreatePlayerHeader());
                Console.WriteLine(StdMsgs.NameClassRacePlayerPrompt(newPlayer));//Show name, class, race info.

                Console.Write(StdMsgs.EnterPwPrompt());
                input = Console.ReadLine();

                Console.Write(StdMsgs.ConfirmPwPrompt());
                pwChk = Console.ReadLine();
                if (input == pwChk)
                {
                    newPlayer.Password = pwChk;
                    Console.WriteLine(StdMsgs.PwConfirmedPrompt());
                    error = false;
                }
                else
                {
                    Console.WriteLine(StdMsgs.PwMisMatchPrompt());
                    Console.ReadLine();
                    error = true;
                }
            } while (error == true);
            Console.ReadLine();
        }

    }//end class
}//end namespace
