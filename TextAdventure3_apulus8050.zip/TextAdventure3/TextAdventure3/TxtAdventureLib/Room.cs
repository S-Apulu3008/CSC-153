﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 4.5.2020
* CSC 153
* Sene Apulu
* TextAdventure3
* Room class
* stores name, description, and exits.
*/

namespace TxtAdventureLib
{
    public class Room
    {
        private string _roomName;
        private string _roomDesc;
        private bool _roomExits;

        public Room()
        {
            RoomName = "";
            RoomDesc = "";
            RoomExits = true;
        }

        public Room(string name, string desc, bool exits)
        {
            RoomName = name;
            RoomDesc = desc;
            RoomExits = exits;
        }

        public string RoomName 
        {
            get 
            {
                return _roomName;
            }
            set 
            {
                _roomName = value;
            }
        }

        public string RoomDesc 
        {
            get 
            {
                return _roomDesc;
            }
            set 
            {
                _roomDesc = value;
            }
        }

        public bool RoomExits 
        {
            get 
            {
                return _roomExits;
            }
            set 
            {
                _roomExits = value;
            }
        }

    }
}
