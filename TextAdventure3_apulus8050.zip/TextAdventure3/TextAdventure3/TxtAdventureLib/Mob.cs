﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 4.5.2020
* CSC 153
* Sene Apulu
* TextAdventure3
* mob class stores name and description
* for now.
*/
namespace TxtAdventureLib
{
    public class Mob
    {
        private string _mobName;
        private string _mobDesc;

        //private int _mobHP;
        //private int _mobStr;
        //private int _mobDef;

        public Mob()
        {
            MobName = "";
            MobDesc = "";
        }

        public Mob(string name, string desc) 
        {
            MobName = name;
            MobDesc = desc;
        }

        public string MobName
        {
            get
            {
                return _mobName;
            }

            set
            {
                _mobName = value;
            }
        }

        public string MobDesc
        {
            get
            {
                return _mobDesc;
            }
            set
            {
                _mobDesc = value;
            }
        }
    }
}
