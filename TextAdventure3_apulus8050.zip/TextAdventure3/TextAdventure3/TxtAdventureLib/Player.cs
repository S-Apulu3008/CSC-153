﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 4.5.2020
* CSC 153
* Sene Apulu
* TextAdventure3
* Player class stores name, pw, class, race, hp, room location.
*/

namespace TxtAdventureLib
{
    public class Player
    {
        //variables
        private string _name;
        private string _password;
        private string _class;
        private string _race;
        private int _hp;
        private int _roomLoc;
        private List <string> _inventory = new List<string>();

        //constructors
            //default
        public Player()
        {
            Name = "";
            Password = "";
            Class = "";
            Race = "";
            HP = 100;
        }
            //custom
        public Player(string name, string pw, string playerClass, string race) 
        {
            Name = name;
            Password = pw;
            Class = playerClass;
            Race = race;
            HP = 100;
            RoomLoc = 0;
        }

        //properties
        public string Name
        {
            get 
            {
                return _name;
            }
            set 
            {
                _name = value;
            }
        }
        public string Password 
        {
            get 
            {
                return _password;
            }
            set 
            {
                _password = value;
            }
        }
        public string Class 
        {
            get 
            {
                return _class;
            }
            set 
            {
                _class = value;
            }
        }
        public string Race
        {
            get 
            {
                return _race;
            }
            set 
            {
                _race = value;
            }
        }
        public int HP
        {
            get 
            {
                return _hp;
            }
            set 
            {
                _hp = value;
            }
        }
        public int RoomLoc //Room Location for player.
        {
            get 
            {
                return _roomLoc;
            }
            set
            {
                _roomLoc = value; 
            }

        }

        //methods
        public void ShowPlayer() 
        {
            Console.WriteLine($"Your player:" +
                            $"\nname: {Name}" +
                            $"\nclass: {Class}" +
                            $"\nrace: {Race}" +
                            $"\nHP: {HP}");
        }
        public void MoveToRoomNorth() 
        {
            RoomLoc++;
        }
        public void MoveToRoomSouth()
        {
            RoomLoc--;
        }

        //Inventory
                //Exploring here.
        public void DisplayInventory()
        {
            Console.WriteLine("Items in inventory:");
            for(int item = 0; item < _inventory.Count;) 
            {
                Console.WriteLine($"{item}. {_inventory[item]}");
            }
        }
        public void AddtoInventory(string item)
        {
            _inventory.Add(item);
            Console.WriteLine($"Item {item.ToLower()} added");
        }
        public void DropfromInventory(string item)
        {
            Console.WriteLine($"{item} removed from inventory.");
            _inventory.Remove(item);
        }
        public void InventoryCount()
        {
            Console.WriteLine($"{_inventory.Count}");
        }
    }
}
