﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 4/25/2020
* CSC 153
* Sene Apulu
* Preferred Customer Class
*/



namespace InheritanceClassDemoLib
{
    public class PreferredCustomer : Customer //Derived from Customer Class.
    {
        //fields
        private double _totalPurchased;
        private double _discountRate;

        //Constructors
        public PreferredCustomer() //Default
        {
            CustNum = 0;
            Name = "";
            Phone = "";
            Address = "";
            TotalPurchased = 0.0;
            OnMailList = false;
        }

        public PreferredCustomer(int custNum, string name, string phone, string address, double totalPurch, bool onList) //Custom
        { 
            CustNum = custNum;
            Name = name;
            Phone = phone;
            Address = address;
            TotalPurchased = totalPurch;
            OnMailList = onList;
        }


        //Properties
        public double TotalPurchased //Cumalitive total of customer's purchase.
        {
            get 
            {
                return _totalPurchased;
            }
            set 
            {
                _totalPurchased = value;
            }
        }

        public double DiscountRate
        {
            get
            {
                return _discountRate;
            }

            set
            {
                _discountRate = value;
            }

        }


        //Methods
        public void SetDiscount() //Set the discount according to TotalPurchased value.
        {
            if (TotalPurchased >= 500.0 && TotalPurchased < 1000.0) //If total purchased is >= 500 and < 1000 
            {
                DiscountRate = .05; //then the discount rate is 5%
            }
            else if (TotalPurchased >= 1000.0 && TotalPurchased < 1500.0)//If total purchased is >= 1000 and < 1500 
            {
                DiscountRate = .06; //then the discount rate is 6%
            }
            else if (TotalPurchased >= 1500.0 && TotalPurchased < 2000.0)//If total purchased is >= 1500 and < 2000
            {
                DiscountRate = .07; //then the discount rate is 7%
            }
            else if (TotalPurchased >= 2000.0)//If total purchased is > 2000
            {
                DiscountRate = .1; //then the discount rate is 10%
            }
            else
            {
                DiscountRate = 0.0; //no discount otherwise.
            }
        }
    }
}
