﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceClassDemoLib
{
    public class StdMsg
    {
        public static string DisplayPrefCustInfo(PreferredCustomer customer) 
        {
            return $"Customer #: {customer.CustNum}\n" +
                   $"Name: {customer.Name}\n" +
                   $"Address: {customer.Address}\n" +
                   $"Phone: {customer.Phone}\n" +
                   $"Total Purchased: ${customer.TotalPurchased}\n" +
                   $"Discount: {customer.DiscountRate * 100}%";
        }
    }
}
