﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InheritanceClassDemoLib;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            PreferredCustomer me = new PreferredCustomer(1, "Sene Apulu", "919-879-8158", "101 Drury Ln.", 499.99, true); //Create Preferred Customer Object.
            PreferredCustomer newCustomer = new PreferredCustomer(2, "Oswald Cobblepot", "910-873-3453", "42 Penguin Lane",250.00, false); //Another Preferred Customer Object.
            
            me.SetDiscount(); //Set Discount for Preferred Customers.
            newCustomer.SetDiscount();

            Console.WriteLine(StdMsg.DisplayPrefCustInfo(newCustomer));
            Console.WriteLine();

            Console.WriteLine(StdMsg.DisplayPrefCustInfo(me)); //Display Preferred Customer info. Discount 0%
            Console.WriteLine();


            me.TotalPurchased += 1.0; //Preferred Customer makes a $1.00 purchase.TotalPurchase is now over $500.00
            me.SetDiscount(); //Set DIscount for Preferred Customer.

            Console.WriteLine(StdMsg.DisplayPrefCustInfo(me)); //Display Preferred Customer info. Discount 5%
            Console.WriteLine();

            me.TotalPurchased += 500.0; //Preferred Customer makes a $500.00 purchase.TotalPurchase is now over $1000.00
            me.SetDiscount(); //Set DIscount for Preferred Customer.

            Console.WriteLine(StdMsg.DisplayPrefCustInfo(me)); //Display Preferred Customer info. Discount 6%
            Console.WriteLine();

            me.TotalPurchased += 500.0; //Preferred Customer makes another $500.00 purchase.TotalPurchase is now over $1500.00
            me.SetDiscount(); //Set DIscount for Preferred Customer.

            Console.WriteLine(StdMsg.DisplayPrefCustInfo(me)); //Display Preferred Customer info. Discount 7%
            Console.WriteLine();

            me.TotalPurchased += 500.0; //Preferred Customer makes another $500.00 purchase.TotalPurchase is now over $2000.00
            me.SetDiscount(); //Set DIscount for Preferred Customer.

            Console.WriteLine(StdMsg.DisplayPrefCustInfo(me)); //Display Preferred Customer info. Discount 10%
            Console.WriteLine();

            Console.ReadLine();
        }
    }
}
