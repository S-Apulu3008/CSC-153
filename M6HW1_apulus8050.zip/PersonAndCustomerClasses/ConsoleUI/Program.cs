﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InheritanceClassDemoLib;
/**
* 4.13.2020
* CSC 153
* Sene Apulu
* Demonstration of class inheritance.
*/


namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //Customer class is derived from Person class.
            //Customer inherits Name, Address and Phone properties.

            Customer newCustomer = new Customer(1, "John Doe", "1555 Olive Lane", "910-444-4444", true);

            //newCustomer.Name = "John Doe";
            //newCustomer.Address = "1555 Olive Lane";
            //newCustomer.Phone = "910-444-4444";
            //newCustomer.CustNum = 1;
            //newCustomer.OnMailList = true;

            Console.WriteLine($"Name: {newCustomer.Name}\n" +
                              $"Address: {newCustomer.Address}\n" +
                              $"Phone: {newCustomer.Phone}\n" +
                              $"Customer#: {newCustomer.CustNum}\n" +
                              $"On Mailing List?: {newCustomer.OnMailList}");
            
            Console.ReadLine();

        }
    }
}
