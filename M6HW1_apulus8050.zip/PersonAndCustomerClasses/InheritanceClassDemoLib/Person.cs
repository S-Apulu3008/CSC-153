﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 4.13.2020
* CSC 153
* Sene Apulu
* Demonstration of class inheritance.
*/

namespace InheritanceClassDemoLib
{
    public class Person
    {
        //fields
        private string _name;       //Person class with 3 fields and properties.
        private string _address;
        private string _phone;

        //constructors
        public Person() 
        {
            _name = "";
            _address = "";
            _phone = "";
        }
        public Person(string name) 
        {
            _name = name;
            _address = "";
            _phone = "";
        }
        public Person(string name, string address)
        {
            _name = name;
            _address = address;
            _phone = "";
        }
        public Person(string name, string address, string phone)
        {
            _name = name;
            _address = address;
            _phone = phone;
        }

        //Properties
        public virtual string Name
        {
            get
            {
                return _name;
            }
            set 
            {
                _name = value;
            }
        }
        public virtual string Address
        {
            get
            {
                return _address;
            }
            set
            {
                _address = value;
            }
        }
        public virtual string Phone
        {
            get
            {
                return _phone;
            }
            set
            {
                _phone = value;
            }
        }
    }
}
