﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/**
* 4.13.2020
* CSC 153
* Sene Apulu
* Demonstration of class inheritance.
*/

namespace InheritanceClassDemoLib
{
    public class Customer : Person //Customer class is derived from Person class.
    {
        private int _custNum;       //hold customer number
        private bool _onMailList;   //true, if customer is on mailing list.

        //Constructors
        public Customer() //default constructor
        {
            CustNum = 0;
            Name = "";
            Address = "";
            Phone = "";
            OnMailList = false;
        }
        
        public Customer(int custNum, string name, string address,//custom constructor
                        string phone, bool onMailingList)
        {
            CustNum = custNum;
            Name = name;
            Address = address;
            Phone = phone;
            OnMailList = onMailingList;
        }

        //Properties;
        public int CustNum 
        {
            get 
            {
                return _custNum;
            }
            set 
            {
                _custNum = value;
            }
        }

        public bool OnMailList 
        {
            get 
            {
                return _onMailList;
            }
            set
            {
                _onMailList = value;
            }
        }
    }
}
