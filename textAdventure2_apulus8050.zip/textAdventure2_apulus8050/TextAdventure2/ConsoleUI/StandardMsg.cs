﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public class StandardMsg
    {

        public static void DisplayMenuPrompt(){
        Console.WriteLine("1. Move North" +
                            "\n2. Move South" +
                            "\n3. Attack" + 
                            "\n4. Exit");
        }

        public static void CantGoSouthPrompt() 
        {
            Console.WriteLine("You can't go any further South.");
        }

        public static void CantGoNorthPrompt()
        {
            Console.WriteLine("You can't go any further North.");
        }

        public static void DisplayExitPrompt() 
        {
            Console.WriteLine("exit.");
        }

        public static void DisplayPrompt(string msg)
        {
            Console.WriteLine(msg);
        }
    }
}
