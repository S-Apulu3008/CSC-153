﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
 Sene Apulu
 CSC 153 Module 1 Test
 2/5/2020

*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            const int arraySize = 5;
            string[] names = new string[arraySize];
            string[] numbers = new string[arraySize];
            List<int> ages = new List<int>();
            int nameCount = 0;
            int numCount = 0;
            int age;

            bool replay = true;
            while(replay)
            {
                Console.Clear();
                Console.WriteLine("1. Enter employee's name." +
                    "\n2. Enter employee's phone number." +
                    "\n3. Enter employee's age." +
                    "\n4. Display employee's information." +
                    "\n5. Display average age of employees." +
                    "\n6. Exit.");
                switch (int.Parse(Console.ReadLine()))
                {
                    case 1:
                        Console.WriteLine("Enter employee's name: ");
                        string name = Console.ReadLine();
                        if (nameCount < names.Length) 
                        {
                            names[nameCount] = name;
                            nameCount++;
                        }
                        else 
                        {
                            Console.WriteLine("You can't add anymore names.");
                            Console.ReadLine();
                            break;
                        }
                        Console.ReadLine();
                        break;

                    case 2:
                        Console.WriteLine("Enter employee's phone number: ");
                        string number = Console.ReadLine();
                        if (numCount < numbers.Length)
                        {
                            numbers[numCount] = number;
                            numCount++;
                        }
                        else
                        {
                            Console.WriteLine("You can't add anymore numbers.");
                            Console.ReadLine();
                            break;
                        }
                        Console.ReadLine();
                        break;

                    case 3:
                        Console.WriteLine("Enter employee's age: ");
                        if (ages.Count() == arraySize)
                        {
                            Console.WriteLine("You can't add anymore ages.");
                        }
                        else 
                        {
                            age = int.Parse(Console.ReadLine());
                            ages.Add(age);
                        }
                        Console.ReadLine();
                        break;

                    case 4:
                        Console.WriteLine("Employee Information: ");
                        displayInfo();
                        Console.ReadLine();
                        break;

                    case 5:
                        Console.WriteLine("Average Age of Employees");
                        double totalAges = 0;
                        for (int i = 0; i < ages.Count; i++)
                        {
                            totalAges += ages[i];
                        }
                        double avgAge = totalAges / ages.Count;
                        Console.WriteLine($"The average age of all the employees: {avgAge}");
                        Console.ReadLine();
                        break;

                    case 6:
                        Console.WriteLine("Program exit.");
                        replay = false;
                        Console.ReadLine();
                        break;

                    default:
                        Console.WriteLine("Invalid choice.");
                        Console.ReadLine();
                        break;

                }

                void displayInfo() 
                {
                    for (int i = 0; i < names.Length; i++)
                    {
                        Console.WriteLine($"Name: {names[i]}\nPhone: {numbers[i]} \nAge: {ages[i]}\n");
                    }
                
                }


            }
        }
    }
}
