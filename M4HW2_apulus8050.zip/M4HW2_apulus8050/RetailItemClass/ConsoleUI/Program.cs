﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using myClassLib;

/*
 * Sene Apulu
 * 3.24.2020
 * Retail Item Class
 * CSC 153 
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //Three RetailItem objects
            RetailItem item1 = new RetailItem("Jacket", 12, 59.05);
            RetailItem item2 = new RetailItem("Jeans", 40, 34.95);
            RetailItem item3 = new RetailItem("Shirt", 20, 24.95);

            //Add them to a list.
            List<RetailItem> inventory = new List<RetailItem> { item1, item2, item3 };

            //Display Header
            Console.WriteLine(StdMsgs.ShowHeader());

            //Display Items
            RetailItem.DisplayItemList(inventory);
            Console.ReadLine();
        }
    }
}
