﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
 * Sene Apulu
 * 3.24.2020
 * Retail Item Class
 * CSC 153 
 */

namespace myClassLib
{
    public class StdMsgs
    {
        public static string ShowHeader() //The header
        {
            return "Item Description".PadRight(20) + "Units On Hand".PadRight(20) +
                   "Price".PadRight(22) + "Total\n" +
                   "------------------------------------------------------------------------".PadLeft(10);
        }

        public static string ShowItemInfo(RetailItem item) //The item's info
        {
            return $"{item.Description.PadRight(20)}{item.UnitsOnHand.ToString().PadRight(20)}" +
                   $"${item.Price.ToString().PadRight(20)} ${string.Format("{0:0.00}",item.ShowTotal())}";
        }
    }
}
