﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
    2/26/2020
    Sene Apulu
    CSC 153
    Module 3 Test apulus8050
 */
namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            //vars
            bool exit = false; //sentry for do-while
            const int SIZE = 5; //constant
            int nameIndex = 0, phoneIndex = 0;

            string[] employeeNames = new string[SIZE]; //array for employee names.
            string[] employeePhones = new string[SIZE];//array for employee phone numbers.
            List<int> employeeAges = new List<int>(); //list for employee ages.

            do
            {
                EmployeeLibrary.StandardMessages.DisplayMenuPrompt(); //display menu.
                switch (Console.ReadLine())//get users choice.
                {
                    case "1":
                        EnterName(ref employeeNames,ref nameIndex);//get employee name and put in name array.
                        break;

                    case "2":
                        EnterNumber(ref employeePhones, ref phoneIndex);//get employee number and put in phone array.
                        break;

                    case "3":
                        EnterAge(ref employeeAges); //get employee age and put in age list
                        break;

                    case "4":
                        Console.WriteLine();
                        DisplayEmployee(employeeNames, employeePhones, employeeAges); //display employees info.
                        break;

                    case "5":
                        DisplayAverageAge(employeeAges); //display average age of employees.
                        break;

                    case "6":
                        exit = true; //break do-while. exits program.
                        break;

                    default:
                        EmployeeLibrary.StandardMessages.InvalidInputPrompt();//prompt user about invalid input.
                        Console.WriteLine();
                        break;
                }//end switch
            } while (exit == false);//end while

        }//end main

        public static void EnterName(ref string[] employeeNames,ref int nameIndex) 
        {
            EmployeeLibrary.StandardMessages.GetNamePrompt();//"enter emp's name: "
            Console.WriteLine();
            employeeNames[nameIndex] = Console.ReadLine();
            nameIndex++;
        }

        public static void EnterNumber(ref string[] employeePhones, ref int phoneIndex) 
        {
            EmployeeLibrary.StandardMessages.GetNumberPrompt();//"enter emp's phone: "
            Console.WriteLine();
            employeePhones[phoneIndex] = Console.ReadLine();
            phoneIndex++;
        }

        public static void EnterAge(ref List<int> employeeAges) 
        {
            EmployeeLibrary.StandardMessages.GetAgePrompt();//"enter age: "
            Console.WriteLine();
            if (int.TryParse(Console.ReadLine(), out int number))
            {
                employeeAges.Add(number);
            }
            else
            {
                EmployeeLibrary.StandardMessages.InvalidInputPrompt();
            }
        }

        public static void DisplayEmployee(string[] names, string[] numbers, List<int> Ages)//displays employees info
        {
            for (int i = 0; i < Ages.Count; i++)
            {
                EmployeeLibrary.StandardMessages.DisplayPrompt("" +
                    $"Employee name: {names[i]}" +
                    $"\nPhone number: {numbers[i]}" +
                    $"\nAge: {Ages[i]}\n");
                Console.WriteLine();
            }
        }

        public static void DisplayAverageAge(List<int> ages) //display average of ages.
        {
           EmployeeLibrary.StandardMessages.DisplayPrompt($"Average age of employees: {ages.Average()}");
           Console.WriteLine();
        }


    }//end class

}//end namespace

