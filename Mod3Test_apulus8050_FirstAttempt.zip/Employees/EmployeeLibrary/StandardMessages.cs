﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class StandardMessages
    {
        public static void DisplayMenuPrompt() 
        {
            Console.Write("1. Enter employee's name." +
                    "\n2. Enter employee's phone number." +
                    "\n3. Enter employees's age." +
                    "\n4. Display employee's information." +
                    "\n5. Display average age of employees." +
                    "\n6. Exit.\n>");
        }
        public static void GetNamePrompt() 
        {
            Console.Write("enter employee's name: ");
        }

        public static void GetNumberPrompt()
        {
            Console.Write("enter employee's name: ");
        }

        public static void GetAgePrompt()
        {
            Console.Write("enter employee's age: ");
        }

        public static void DisplayPrompt(string msg) 
        {
            Console.WriteLine(msg);
        }

        public static void InvalidInputPrompt() 
        {
            Console.WriteLine("Invalid Input");
        }

    }
}
