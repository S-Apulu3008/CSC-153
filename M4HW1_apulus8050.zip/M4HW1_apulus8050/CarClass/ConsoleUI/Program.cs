﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/*
* Date
* CSC 153
* 3.18.2020
* M4HW1_CarClass_Assignment
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool replay = true; //sentinel for do-while
            bool carCreated = false; //when car is created will be assigned true.
            myClassLib.Car aCar = new myClassLib.Car(); //create Car object.
            do
            {
                Console.Clear();//clear screen
                Console.WriteLine(myClassLib.StdMsgs.DisplayMenu(carCreated));//Display proper menu.
                switch (Console.ReadLine())
                {
                    case "1"://Create Car/Show Car
                        if (carCreated == false)
                        {
                            myClassLib.BuildCar.BuildACar(aCar);
                            Console.WriteLine(myClassLib.StdMsgs.ShowCar(aCar));
                            Console.ReadLine();
                            carCreated = true;
                            break;
                        }
                        else
                        {
                            Console.WriteLine(myClassLib.StdMsgs.ShowCar(aCar));
                            Console.ReadLine();
                            break;
                        }
                    case "2"://Accelerate
                        if (carCreated == false)
                        {
                            Console.WriteLine(myClassLib.StdMsgs.NoCarPrompt());
                            Console.ReadLine();
                            break;
                        }
                        else
                        {
                            aCar.Accelerate();
                            Console.WriteLine(myClassLib.StdMsgs.ShowSpeed(aCar));
                            Console.ReadLine();
                            break;
                        }
                    case "3"://Brake
                        if (carCreated == false)
                        {
                            Console.WriteLine(myClassLib.StdMsgs.NoCarPrompt());
                            Console.ReadLine();
                            break;
                        }
                        else 
                        {
                            aCar.Brake();
                            Console.WriteLine(myClassLib.StdMsgs.ShowSpeed(aCar));
                            Console.ReadLine();
                            break;
                        }
                    case "4"://Exit
                        replay = false;
                        break;
                    default:
                        Console.WriteLine(myClassLib.StdMsgs.DisplayBadInputPrompt());
                        Console.ReadLine();
                        break;
                }//end switch

            } while (replay == true); //end do-while

        }//end main
    }//end class
}//end namespace
