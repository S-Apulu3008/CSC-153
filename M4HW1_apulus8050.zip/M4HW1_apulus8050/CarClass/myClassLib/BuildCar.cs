﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/*
* Date
* CSC 153
* 3.18.2020
* Build Car Class
*/
namespace myClassLib
{
    public class BuildCar
    {
        public static void BuildACar(Car userCar)
        {
            bool error = true;
            do
            {
                Console.WriteLine(StdMsgs.AskForMakePrompt());
                userCar.Make = Console.ReadLine();

                Console.WriteLine(StdMsgs.AskForYearPrompt());
                userCar.Year = ConvToInt(Console.ReadLine());
                if (userCar.Year < 0)
                {
                    Console.WriteLine(StdMsgs.DisplayYearErrorPrompt());
                    error = true;
                }
                else
                {
                    error = false;
                }
            }
            while (error == true);
        }

        public static int ConvToInt(string input)
        {
            int output;
            if (int.TryParse(input, out output))
            {
                return output;
            }
            else 
            {
                output = -1;
                return output;
            }
        }
    }
}
